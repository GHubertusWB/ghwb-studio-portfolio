'use client'
import { motion } from 'framer-motion'
import { useState, useEffect } from 'react'
import { 
  ComputerDesktopIcon, 
  DevicePhoneMobileIcon, 
  PresentationChartLineIcon, 
  UserIcon, 
  EnvelopeIcon, 
  ChatBubbleLeftRightIcon 
} from '@heroicons/react/24/outline'
import { Button } from '@/components/ui/Button'

interface ContactFormUXUIProps {
  // Keine Props benötigt
}

export default function ContactFormUXUI(): React.JSX.Element {
  const [selectedSubjectTags, setSelectedSubjectTags] = useState<string[]>([])
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle')
  const [isClient, setIsClient] = useState(false)

  // Hydration fix
  useEffect(() => {
    setIsClient(true)
  }, [])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData(prev => ({
      ...prev,
      [name]: value
    }))
  }

  const handleCardClick = (subject: string): void => {
    setSelectedSubjectTags(prev => {
      if (prev.includes(subject)) {
        return prev.filter(tag => tag !== subject)
      } else {
        return [...prev, subject]
      }
    })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      // E-Mail über API-Route senden
      const response = await fetch('/api/send-email', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name: formData.name,
          email: formData.email,
          message: formData.message,
          selectedSubjects: selectedSubjectTags,
          variant: 'uxui'
        }),
      })

      if (response.ok) {
        setSubmitStatus('success')
        
        // Formular nach erfolgreichem Versand zurücksetzen
        setTimeout(() => {
          setFormData({ name: '', email: '', message: '' })
          setSelectedSubjectTags([])
          setSubmitStatus('idle')
        }, 5000)
      } else {
        const errorData = await response.json()
        console.error('Fehler beim Senden:', errorData)
        setSubmitStatus('error')
      }
      
    } catch (error) {
      console.error('Fehler beim Senden der E-Mail:', error)
      setSubmitStatus('error')
    } finally {
      setIsSubmitting(false)
    }
  }

  const subjectCards = [
    {
      id: 'Website-Design',
      title: 'Website-Design',
      description: 'Responsive Websites und Web-Anwendungen',
      icon: <ComputerDesktopIcon className="w-5 h-5 text-gray-700" />
    },
    {
      id: 'App-Design',
      title: 'App-Design',
      description: 'Mobile Apps für iOS und Android',
      icon: <DevicePhoneMobileIcon className="w-5 h-5 text-gray-700" />
    },
    {
      id: 'UX-Beratung',
      title: 'UX-Beratung',
      description: 'User Research und Usability-Optimierung',
      icon: <PresentationChartLineIcon className="w-5 h-5 text-gray-700" />
    }
  ]

  // Prevent hydration issues
  if (!isClient) {
    return (
      <div className="w-full max-w-2xl mx-auto">
        <div className="relative bg-white border-2 border-gray-900 p-8">
          <div className="animate-pulse">
            <div className="h-4 bg-gray-200 rounded w-1/4 mb-4"></div>
            <div className="space-y-4">
              <div className="h-20 bg-gray-200 rounded"></div>
              <div className="h-20 bg-gray-200 rounded"></div>
              <div className="h-20 bg-gray-200 rounded"></div>
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8 }}
      viewport={{ once: true }}
      className="w-full max-w-2xl mx-auto"
    >
      <div 
        className="relative bg-white border-2 border-gray-900 p-8"
        style={{  }}
      >
        {/* Simple line decorations */}
        <div className="absolute top-0 left-8 w-16 h-1 bg-gray-900"></div>
        <div className="absolute bottom-0 right-8 w-16 h-1 bg-gray-900"></div>

        {/* Subject Cards */}
        <motion.div 
          className="mb-8"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          viewport={{ once: true }}
        >
          <h3 className="text-sm font-bold text-gray-900 mb-4 tracking-wider uppercase">Betreff wählen</h3>
          
          <div className="grid md:grid-cols-3 gap-4 mb-6">
            {subjectCards.map((card, index) => (
              <motion.div
                key={card.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 + index * 0.1 }}
                viewport={{ once: true }}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <Button
                  variant={selectedSubjectTags.includes(card.id) ? "primary" : "secondary"}
                  size="base"
                  onClick={() => handleCardClick(card.id)}
                  className={`w-full p-4 text-left group justify-start ${
                    selectedSubjectTags.includes(card.id)
                      ? 'bg-gray-900 text-white border-gray-900' 
                      : 'bg-white text-gray-900 border-gray-900 hover:bg-gray-100'
                  }`}
                  icon="left"
                  iconElement={card.icon}
                >
                  <div className="flex flex-col items-start">
                    <span className="font-bold text-sm mb-1">{card.title}</span>
                    <p className="text-xs leading-relaxed opacity-80">
                      {card.description}
                    </p>
                  </div>
                </Button>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Name Input */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            viewport={{ once: true }}
          >
            <label htmlFor="name" className="block text-sm font-bold text-gray-900 mb-2 tracking-wider uppercase">
              Name
            </label>
            <div className="relative">
              <input
                id="name"
                name="name"
                type="text"
                required
                value={formData.name}
                onChange={handleInputChange}
                className="w-full px-4 py-3 border-2 border-gray-900 bg-white text-gray-900 placeholder-gray-500 focus:outline-none focus:bg-gray-50 transition-colors duration-200"
                style={{  }}
                placeholder="Ihr vollständiger Name"
              />
              <UserIcon className="absolute right-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-500" />
            </div>
          </motion.div>

          {/* Email Input */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            viewport={{ once: true }}
          >
            <label htmlFor="email" className="block text-sm font-bold text-gray-900 mb-2 tracking-wider uppercase">
              E-Mail
            </label>
            <div className="relative">
              <input
                id="email"
                name="email"
                type="email"
                required
                value={formData.email}
                onChange={handleInputChange}
                className="w-full px-4 py-3 border-2 border-gray-900 bg-white text-gray-900 placeholder-gray-500 focus:outline-none focus:bg-gray-50 transition-colors duration-200"
                style={{  }}
                placeholder="ihre.email@beispiel.de"
              />
              <EnvelopeIcon className="absolute right-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-500" />
            </div>
          </motion.div>

          {/* Message Textarea */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.5 }}
            viewport={{ once: true }}
          >
            <label htmlFor="message" className="block text-sm font-bold text-gray-900 mb-2 tracking-wider uppercase">
              Nachricht
            </label>
            <div className="relative">
              <textarea
                id="message"
                name="message"
                required
                rows={6}
                value={formData.message}
                onChange={handleInputChange}
                className="w-full px-4 py-3 border-2 border-gray-900 bg-white text-gray-900 placeholder-gray-500 focus:outline-none focus:bg-gray-50 transition-colors duration-200 resize-none"
                style={{  }}
                placeholder="Beschreiben Sie Ihr UX/UI Projekt oder Ihre Anfrage..."
              />
              <ChatBubbleLeftRightIcon className="absolute right-3 top-3 w-5 h-5 text-gray-500" />
            </div>
          </motion.div>

          {/* Submit Button */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.6 }}
            viewport={{ once: true }}
            className="pt-4"
          >
            <motion.div
              whileHover={!isSubmitting ? { scale: 1.02 } : {}}
              whileTap={!isSubmitting ? { scale: 0.98 } : {}}
            >
              <Button
                type="submit"
                disabled={isSubmitting}
                variant={
                  submitStatus === 'success' ? 'primary' :
                  submitStatus === 'error' ? 'secondary' : 'primary'
                }
                size="base"
                className={`w-full font-bold text-sm tracking-wider uppercase ${
                  isSubmitting 
                    ? 'bg-gray-200 text-gray-500 cursor-not-allowed' 
                    : submitStatus === 'success'
                    ? 'bg-green-100 text-green-800 border-green-600'
                    : submitStatus === 'error'
                    ? 'bg-red-100 text-red-800 border-red-600'
                    : 'bg-gray-900 text-white hover:bg-gray-800'
                }`}
                style={{ border: '2px solid', borderColor: 
                  submitStatus === 'success' ? '#16a34a' :
                  submitStatus === 'error' ? '#dc2626' : '#111827'
                }}
              >
                {isSubmitting ? 'Nachricht wird gesendet...' : 
                 submitStatus === 'success' ? 'Nachricht gesendet!' :
                 submitStatus === 'error' ? 'Fehler - Bitte erneut versuchen' :
                 'Nachricht senden'}
              </Button>
            </motion.div>
          </motion.div>
        </form>

        {/* Status Messages */}
        {submitStatus === 'success' && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-4 p-4 bg-green-100 border-2 border-green-600 text-green-800 text-sm"
          >
            <strong>Erfolgreich!</strong> Ihre Nachricht wurde gesendet. Ich melde mich zeitnah bei Ihnen.
          </motion.div>
        )}

        {submitStatus === 'error' && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-4 p-4 bg-red-100 border-2 border-red-600 text-red-800 text-sm"
          >
            <strong>Fehler!</strong> Beim Senden ist ein Problem aufgetreten. Bitte versuchen Sie es erneut.
          </motion.div>
        )}
      </div>
    </motion.div>
  )
}
