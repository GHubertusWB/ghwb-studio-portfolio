'use client'

import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { MessageCircle } from 'lucide-react'
import { Button } from './ui/Button'
import { SpecialButton } from './ui/SpecialButton'
import { SpecialButtonDark } from './ui/SpecialButtonDark'
import ContactModal from './ContactModal'
import { useTheme } from '@/contexts/ThemeContext'

interface FloatingContactButtonProps {
  title?: string
  subtitle?: string
}

/**
 * FloatingContactButton Component
 * 
 * Globales floating contact button system mit Modal.
 * Kann auf allen Seiten verwendet werden.
 * 
 * @param {FloatingContactButtonProps} props - Komponenten Props
 * @returns {JSX.Element} Das floating button system
 */

export default function FloatingContactButton({
  title = 'Kontakt aufnehmen',
  subtitle = 'Haben Sie ein Projekt im Kopf oder möchten Sie einfach Hallo sagen? Ich freue mich auf Ihre Nachricht.'
}: FloatingContactButtonProps): React.JSX.Element {
  
  // Verwende das aktuelle Theme aus dem Context
  const { theme } = useTheme()
  const [showStickyButton, setShowStickyButton] = useState(false)
  const [buttonBottomOffset, setButtonBottomOffset] = useState(16) // 1rem in px
  const [isContactModalOpen, setIsContactModalOpen] = useState(false)

  // Scroll-Handler für sticky button visibility und position
  useEffect(() => {
    const handleScroll = () => {
      const heroHeight = window.innerHeight // Hero ist full height
      const scrollPosition = window.scrollY
      const windowHeight = window.innerHeight
      const documentHeight = document.documentElement.scrollHeight
      const footerHeight = 530 // Geschätzte Footer-Höhe
      const baseOffset = 18 // 1rem in px

      // Button erscheint nach dem Hero
      const shouldShow = scrollPosition > heroHeight * 0.8
      setShowStickyButton(shouldShow)

      // Button position dynamisch anpassen
      const distanceFromBottom = documentHeight - (scrollPosition + windowHeight)
      
      if (distanceFromBottom < footerHeight + baseOffset) {
        // Button wird vom Footer nach oben geschoben
        const pushUpDistance = footerHeight + baseOffset - distanceFromBottom
        setButtonBottomOffset(baseOffset + pushUpDistance)
      } else {
        // Normale Position
        setButtonBottomOffset(baseOffset)
      }
    }

    window.addEventListener('scroll', handleScroll)
    // Initial check
    handleScroll()

    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  // Global event listener für Hero-Button
  useEffect(() => {
    const handleGlobalContactOpen = () => {
      setIsContactModalOpen(true)
    }

    window.addEventListener('openContactModal', handleGlobalContactOpen)
    return () => window.removeEventListener('openContactModal', handleGlobalContactOpen)
  }, [])

  const openContactModal = () => {
    setIsContactModalOpen(true)
  }

  const closeContactModal = () => {
    setIsContactModalOpen(false)
  }

  return (
    <>
      {/* Contact Modal */}
      <ContactModal
        isOpen={isContactModalOpen}
        onClose={closeContactModal}
        title={title}
        subtitle={subtitle}
      />

      {/* Sticky Contact Button */}
      <AnimatePresence mode="wait">
        {showStickyButton && (
          <motion.div
            key="floating-button"
            className="fixed right-4 z-50 hidden sm:block"
            style={{
              bottom: `${buttonBottomOffset}px`
            }}
            initial={{ opacity: 0, scale: 0.8, y: 20 }}
            animate={{ 
              opacity: 1, 
              scale: 1, 
              y: 0
            }}
            exit={{ opacity: 0, scale: 0.8, y: 20 }}
            transition={{ 
              duration: 0.3, 
              ease: "easeOut"
            }}
          >
            {theme === 'dark' ? (
              <SpecialButtonDark
                variant="primary"
                rounded={true}
                size="lg"
                onClick={openContactModal}
                icon="left"
                iconElement={<MessageCircle className="w-5 h-5" />}
                className="rounded-full"
              >
                Kontakt
              </SpecialButtonDark>
            ) : (
              <SpecialButton
                variant="primary"
                size="medium"
                onClick={openContactModal}
              >
                <div className="flex items-center">
                  <MessageCircle className="w-5 h-5 mr-2" />
                  Kontakt
                </div>
              </SpecialButton>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
