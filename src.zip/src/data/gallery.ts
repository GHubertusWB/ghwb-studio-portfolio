// Gruppierte Galerie-Daten für den Export
export interface GalleryGroup {
  id: string;
  title: string;
  description: string;
  images: string[];
}

// Photography Gruppen
export const photographyGroups: GalleryGroup[] = [
  {
    id: 'natur',
    title: 'Natur & Landschaft',
    description: 'Impressionen aus der Natur',
    images: [
      '/gallery/photography/19F9439B-6752-4045-A9F5-249B25A84474_1_105_c.jpeg',
      '/gallery/photography/328A7954-AFB7-4328-AB07-E5DE9E9CE57A_4_5005_c.jpeg',
      '/gallery/photography/39E42341-C458-430D-AD2F-FB7A7C81696F_4_5005_c.jpeg',
      '/gallery/photography/3ECA00A0-9549-45C8-82AB-D53187D86670_4_5005_c.jpeg',
      '/gallery/photography/46335F0C-7C1E-424B-BB30-01760EB6E3FC_1_105_c.jpeg',
      '/gallery/photography/4A785E0A-8066-4896-87C5-6FA3C37F71DF_1_105_c.jpeg',
      '/gallery/photography/60BCB42F-CEFE-4375-B53C-95C98BE9B872_1_105_c.jpeg',
    ]
  },
  {
    id: 'street',
    title: 'Street & Urban',
    description: 'Urbane Szenen und Architektur',
    images: [
      '/gallery/photography/6D90E359-0123-44F3-85FE-64C53AA88563_1_102_o.jpeg',
      '/gallery/photography/7D60AD01-7FB3-4A65-B6A9-F0D26EB13F03_1_105_c.jpeg',
      '/gallery/photography/7D6F2134-EA2F-46CE-AFD8-4BD5084BEEE9_1_105_c.jpeg',
      '/gallery/photography/80F190D7-4161-4786-9D04-5B645361C06F_1_102_o.jpeg',
      '/gallery/photography/92790EEE-C865-4356-9B9E-FD95FDEC23F0_1_102_o.jpeg',
      '/gallery/photography/AB89B79B-69C1-42B0-90A3-DBAACF7F66DC_1_105_c.jpeg',
      '/gallery/photography/AE26D16C-C6C1-4899-B89F-50E1DFAE9DC3_4_5005_c.jpeg',
    ]
  },
  {
    id: 'portrait',
    title: 'Portrait & Menschen',
    description: 'Charakterstudien und Portraits',
    images: [
      '/gallery/photography/B2E14E71-1560-40B9-8977-797C99B7B1B1_1_102_o.jpeg',
      '/gallery/photography/D44CA91B-9539-4A72-BAAC-3F19A25CEA71_4_5005_c.jpeg',
      '/gallery/photography/E14B39AB-4294-4BDD-A606-7DE4125565C0_4_5005_c.jpeg',
      '/gallery/photography/E88C9C53-D7D0-4A85-94BD-44E5507AB095_4_5005_c.jpeg',
      '/gallery/photography/F70E35BF-5333-48AA-A762-40B561AE7BA2_4_5005_c.jpeg',
      '/gallery/photography/F74F5006-A597-4969-B0BB-7A1751D8E5CA_1_105_c.jpeg',
      '/gallery/photography/FDDC9242-A75E-4540-8148-13D5C2C4A5F6_1_105_c.jpeg',
    ]
  }
];

// Art Gruppen
export const artGroups: GalleryGroup[] = [
  {
    id: 'leinwaende',
    title: 'Leinwände',
    description: 'Klassische Malerei auf Leinwand',
    images: [
      '/gallery/art/276978157_2151325001689082_4554386259994847710_n.jpg',
      '/gallery/art/277112623_365261895528667_8618673296825249071_n.jpg',
      '/gallery/art/277115346_365186875527721_6944956018215836686_n.jpg',
      '/gallery/art/277116953_2633713603439940_5567031316271926133_n.jpg',
      '/gallery/art/277146706_952139549001862_8625110162078269767_n.jpg',
      '/gallery/art/277150484_165558015829388_690578249072834079_n.jpg',
      '/gallery/art/277151002_129046586360490_3499358518634205765_n.jpg',
      '/gallery/art/277215437_706567053685650_9050058375445279400_n.jpg',
      '/gallery/art/277216951_926003048079210_1502436782965493203_n.jpg',
      '/gallery/art/277217118_1145694299530737_5721185692071360096_n.jpg',
      '/gallery/art/277243093_1248748055533077_1369662099054558820_n.jpg',
      '/gallery/art/277243653_777330239907739_4675723590761473877_n.jpg',
      '/gallery/art/277243830_1414959182258562_8940340388106365620_n.jpg',
      '/gallery/art/277245074_3139111506404515_8161765070889220654_n.jpg',
      '/gallery/art/277251408_331523955498707_7237743588803408990_n.jpg',
      '/gallery/art/277255518_1000239017265117_680864452724461122_n.jpg',
      '/gallery/art/277293148_1598356407200102_239692606235846820_n.jpg',
      '/gallery/art/277317970_2341734385980566_3538565766485004224_n.jpg',
      '/gallery/art/277321724_987458655308497_2472807721105867412_n.jpg',
      '/gallery/art/277325496_397953058823402_5282921994824053370_n.jpg',
      '/gallery/art/277364421_2194885440676474_6891500588507266767_n.jpg',
      '/gallery/art/60172564_429516391175437_1885654865181764035_n.jpg',
    ]
  },
  {
    id: 'digiducks',
    title: 'Digiducks',
    description: 'Digitale Entchen-Kunst',
    images: [
      '/gallery/art/0C0FF1CB-BB55-4087-B418-A7D493B5EC7F_1_105_c.jpeg',
      '/gallery/art/0E4EC7D6-556E-4732-B9BB-6C2861557E36_1_105_c.jpeg',
      '/gallery/art/1A01DAE4-D2AA-4133-B425-238B102646DA_1_105_c.jpeg',
      '/gallery/art/23362AF2-14C8-4008-A49C-CF39565BD946_1_105_c.jpeg',
      '/gallery/art/30BD9B42-2640-4CAE-B7AB-126BD185EE3E_1_105_c.jpeg',
      '/gallery/art/32AC3539-6CC4-4D96-B215-37902BB94951_1_105_c.jpeg',
      '/gallery/art/3CFD249E-C459-49C3-B669-29C627771E61_1_105_c.jpeg',
      '/gallery/art/3EEB194F-AFEC-4264-A8C8-403B5E3EE764_1_105_c.jpeg',
      '/gallery/art/42018879-4B58-4455-BC72-53C072806449_1_105_c.jpeg',
      '/gallery/art/4D5D8262-2FC9-4D92-BDDF-CC7937346020_1_105_c.jpeg',
      '/gallery/art/4E5E9ECA-63E4-489C-B850-C9F30C046F77_1_105_c.jpeg',
      '/gallery/art/4E65B280-9DA5-4397-9003-0FC80A93C13B_1_105_c.jpeg',
      '/gallery/art/5D89E4F3-E1CF-44C9-A62B-E5D67FC312AE_1_105_c.jpeg',
      '/gallery/art/6E2DD651-ABAB-4561-A7D7-EE776C7698D3_1_105_c.jpeg',
      '/gallery/art/7167E6A9-AB85-43B8-B6B0-2FBAF06111AC_1_105_c.jpeg',
    ]
  },
  {
    id: 'semantic-ducks',
    title: 'Semantic Ducks',
    description: 'Semantische Entchen-Interpretationen',
    images: [
      '/gallery/art/76825CEC-4305-466A-B431-EFD7F61DA8AC_1_105_c.jpeg',
      '/gallery/art/881F527F-9EB2-4F86-988A-CB7C0F2A2BB7_1_105_c.jpeg',
      '/gallery/art/881F7165-B85A-474D-B816-AE4E2ED1222A_1_105_c.jpeg',
      '/gallery/art/96014BAB-DF07-4A60-A2EB-FDE1D39EDBE7_1_105_c.jpeg',
      '/gallery/art/9C0842D7-02E4-4582-9C0D-662C20886B88_1_105_c.jpeg',
      '/gallery/art/9F135F71-8C67-463D-A9FD-4EC30C11A694_1_105_c.jpeg',
      '/gallery/art/A6ED9672-C13E-41D6-8279-63E9B1E60A76_1_105_c.jpeg',
      '/gallery/art/B7E0B83B-4387-4DD8-A041-69A6DBCF1618_1_105_c.jpeg',
      '/gallery/art/B9471E79-A977-42AC-84F0-1A029B6E6A6A_1_105_c.jpeg',
      '/gallery/art/C6AD7C1A-5BFF-48A2-A7A4-B7FCD3BE99F6_1_105_c.jpeg',
      '/gallery/art/C955FF36-595A-46A1-9298-0EBB9F3BD679_1_105_c.jpeg',
      '/gallery/art/DD606F61-3FF0-4231-8CC1-5BF790C0B1A0_1_105_c.jpeg',
      '/gallery/art/E4BEFC2E-FF3F-416D-8E65-837AC722D306_1_105_c.jpeg',
      '/gallery/art/F4C7EE68-E9B7-4750-969F-B8410EC65B39_1_105_c.jpeg',
      '/gallery/art/F672889F-77D2-4C59-8D0A-222E78DCC1CA_1_105_c.jpeg',
    ]
  }
];

// Legacy Arrays für Backward Compatibility
export const photographyImages = photographyGroups.flatMap(group => group.images);
export const artImages = artGroups.flatMap(group => group.images);
